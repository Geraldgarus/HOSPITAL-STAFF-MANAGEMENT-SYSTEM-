<?php
$servername = "localhost";
$username = "root";
$password = "";
$dababase_name="hospital000";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dababase_name);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

?> 