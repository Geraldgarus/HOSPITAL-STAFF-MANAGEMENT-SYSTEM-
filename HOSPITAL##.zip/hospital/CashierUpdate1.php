<?php
include("connection.php");

if(isset($_POST["update"])){

    $id =$_GET["id"];
    $name =$_POST["name"];
    $investigation =$_POST["investigation"];
    $medicine =$_POST["medicine"];
    $cost =$_POST["cost"];


 $update_user = "UPDATE cashiertable  SET  name='$name',investigation='$investigation',medicine='$medicine',cost='$cost'
    WHERE  id='$id'";

    if (mysqli_query($conn, $update_user)) {
           header("location:cashierCOMPLETED.php");
           exit();
    } else {
        echo "wrong updation try again";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>update</title>
    <style>
      
        .form{
            display: block;
            background-color:white;
            height:800px;
            width: 1300px;
            margin-left: 30px;
            padding-left: 50px;
            margin-top: 50px;

        }
        input{
            padding: 15px 470px;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: center;
            border-color:whitesmoke;
        

        }
        h1{
            font-size: 30px;
            text-align: center;
            color: black;
        }
       input .placeholder{
        text-align: left;
        background-color: black;
       }
       button{
        padding: 20px 578px;
       
        color: white;
        background-color: blue;
        
        font-size: 20px;
       }
       h2{
        font-size: 30px;

       }
       p{
        background-color: color: purple;
       }
       textarea{
        background-color: transparent;
        color: black;
        font-size: 20px;
        text-align: center;
        border-color: wheat;
       
       }
       

    </style>
  </head>
  <body>
  <?php
include("CASHIER.php");
?>
<div class="shaddow">
    <div class="form">
    <form action="" method="post">
      <h1>please fill the box below</h1>
      <br><br>
      <?php
                $select_user = "select * from cashiertable  where id = '" .$_GET['id']. "'";
                $result = mysqli_query($conn, $select_user);
                $number = mysqli_num_rows($result);
                 if ($number > 0) {
                     while($row = mysqli_fetch_assoc($result)) {  ?>   

      
      <label><h2>*Name</h2></label>
      <input type="text" name="name"  value="<?php echo $row['name']; ?>" placeholder="name">
      <br><br>
      
     
      <label><h2>*Investigation</h2></label>
      <input type="text" name="investigation"  value="<?php echo $row['investigation']; ?>" placeholder="">
    <br>
        
    <label><h2>*Medicine</h2></label>
    <input type="text" name="medicine"  value="<?php echo $row['medicine']; ?>" placeholder="">
    <br>
        
        <label><h2>*Cost</h2></label>
        <input type="text" name="cost"  value="<?php echo $row['cost']; ?>" placeholder="">
    
      <?php  } } ?>
      <br><br><br>
      <button type="submit" name="update">Update</button>
    </form>
    </div>
    </div>
  </body>
</html>