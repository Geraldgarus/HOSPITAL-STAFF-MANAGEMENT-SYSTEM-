<?php
include("connection.php");

if(isset($_POST["insert_user_data"])){
  $name  = $_POST['name'];
  $description= $_POST['description'];
  $room= $_POST['room'];
 
 





$enroll_new_patients = "INSERT INTO  reception1(name,description,room ) VALUES('$name','$description','$room ');";

if (mysqli_query($conn,$enroll_new_patients)) {
  echo "<script>window.location='receregistration.php'</script>";
} else {
  echo "wrong  try again";
}

mysqli_close($conn);

}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Registration</title>
    <style>
      
        .form{
            display: block;
            background-color:white;
            height:800px;
            width: 1400px;
            margin-left: 30px;
            padding-left: 50px;
            margin-top: 50px;

        }
        input{
            padding: 15px 470px;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: left;
            border-color:whitesmoke;
        

        }
        h1{
            font-size: 30px;
            text-align: center;
            color: black;
        }
       input .placeholder{
        text-align: left;
        background-color: black;
       }
       button{
        padding: 20px 578px;
       
        color: white;
        background-color: blue;
        
        font-size: 20px;
       }
       h2{
        font-size: 30px;

       }
       p{
        background-color: color: purple;
       }
       textarea{
        background-color: transparent;
        color: black;
        font-size: 20px;
        text-align: center;
        border-color: wheat;
       
       }
       

    </style>
  </head>
  <body>
  <?php
include("reception1.php");
?>
<div class="shaddow">
    <div class="form">
    <form action="" method="post">
      <h1>please fill the box below</h1>
      <br><br>
      <label><h2>*name</h2></label>
      <input type="text" name="name" placeholder="name">
      <br><br>
      
      <label><h2>*description</h2></label>
      <input type="text" name="description" placeholder="Doctor type">
      <br><br>
      <label><h2>*Room</h2></label>
      <input type="text" name="room" placeholder="room"><br><br><br>
      <button type="submit" name="insert_user_data">submit</button>
    </form>
    </div>
    </div>
  </body>
</html>