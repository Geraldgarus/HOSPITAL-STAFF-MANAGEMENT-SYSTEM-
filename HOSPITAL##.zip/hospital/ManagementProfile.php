<?php
include("connection.php");

if(isset($_POST["update"])){

    $id =$_GET["id"];
    $name =$_POST["name"];
    $email =$_POST["email"];
    $password = md5($_POST['password']);


 $update_user = "UPDATE management SET  name='$name',email='$email',password='$password'
    WHERE  id='$id'";

    if (mysqli_query($conn, $update_user)) {
           header("location:managementdashboard.php");
           exit();
    } else {
        echo "wrong updation try again";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>profile</title>
    <style>
      
        .form{
            display: block;
            background-color:transparent;
            height:900px;
            width: 1300px;
            margin-left: 30px;
            padding-left: 50px;
            margin-top: 50px;

        }
        input{
            padding: 15px 470px;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: center;
            border-color:whitesmoke;
            border-top-color:whitesmoke;
            border-right-color:whitesmoke;
            border-bottom-color: whitesmoke;
        

        }
        h1{
            font-size: 30px;
            text-align: center;
            color: black;
        }
       input .placeholder{
        text-align: left;
        background-color: black;
       }
       button{
        padding: 20px 578px;
       
        color: white;
        background-color: blue;
        
        font-size: 20px;
       }
       h2{
        font-size: 30px;

       }
       p{
        background-color: color: purple;
       }
       textarea{
        background-color: transparent;
        color: black;
        font-size: 20px;
        text-align: center;
        border-color: wheat;
       
       }
       

    </style>
  </head>
  <body>
  <?php
include("management.php");
?>

    <div class="form">
    <form action="" method="post">
      <h1>PROFILE</h1>
      <br><br>
      <?php
                $select_user = "select * from  management where id = '" .$_GET['id']. "'";
                $result = mysqli_query($conn, $select_user);
                $number = mysqli_num_rows($result);
                 if ($number > 0) {
                     while($row = mysqli_fetch_assoc($result)) {  ?>   



      <label><h2>*Name</h2></label>
      <input type="text" name="name"  value="<?php echo $row['name']; ?>" placeholder="name" required>
      <br>
      
      <label><h2>*Email</h2></label>
      <input type="text" name="email" value="<?php echo $row['email']; ?>" placeholder="email" required>
      <br><br>
      <H1>Change password</H1>
      <label><h2>*Old Password</h2></label>
      <input type="password" name="password" placeholder="password" required><br><br><br>
  <br>
  <label><h2>*New Password</h2></label>
      <input type="password" name="password" placeholder="password" required><br><br><br>
  
      <?php  } } ?>
      <br>
      <button type="submit" name="update">submit</button>
    </form>
    </div>
    </div>
  </body>
</html>