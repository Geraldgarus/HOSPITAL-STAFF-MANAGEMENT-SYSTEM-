<?php
include("connection.php");

?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8" />
    <title>DASHBOARD</title>
    <link rel="stylesheet" href="hogo9.css" />
    <!-- Boxicons CDN Link -->
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
        .box {
            background: #fff;
            padding: 20px;
            border-radius: 100%;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
            animation: bounce 2s infinite;
            /* Apply bouncing animation */
        }

        .box:hover {
            animation: none;
            /* Stop animation on hover */
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-30px);
            }

            60% {
                transform: translateY(-15px);
            }
        }
    </style>
    <!-- Boxicons CDN Link -->
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
<?php
include("management.php");
?>
<div class="home-content">
    <div class="overview-boxes">
        <div class="box">
            <div class="right-side">
                <div class="box-topic">Appointments</div>
                <?php
$countusers = mysqli_query($conn, "select id from attedtable1");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
                <div class="indicator">
                <i class="bx bx-calendar"></i>
                    <span class="text">Today</span>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="right-side">
                <div class="box-topic">Feedbacks</div>
                <?php
$countusers = mysqli_query($conn, "select id from labtable");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
                <div class="indicator">
                <i class="bx bx-message-square-detail"></i>
                    <span class="text">Todayk</span>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="right-side">
                <div class="box-topic">cash</div>
                <?php
$countusers = mysqli_query($conn, "select id from cashiertable");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
                <div class="indicator">
                <i class="bx bx-money"></i>
                    <span class="text">Today</span>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="right-side">
                <div class="box-topic">completed</div>
                <?php
$countusers = mysqli_query($conn, "select id from phamaconfirm ");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
                <div class="indicator">
                <i class="bx bx-check"></i>
                    <span class="text">Today</span>
                </div>
            </div>
        </div>
    </div>
    <div class="center">
    </div>
</div>
</body>
</html>
