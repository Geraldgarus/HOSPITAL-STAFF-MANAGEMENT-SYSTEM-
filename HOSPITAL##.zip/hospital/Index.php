<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>indexpage</title>
    <style>
        .body {
            background-image: url(photo.jpg);
            height: 1500px;
            width: 100%;
            background-repeat: round;
            position: fixed;
        }

        a {
            color: white;
            font-size: 25px;
            margin-left: 20px;
            text-align: bottom;
            text-decoration: none;
            margin-top: 40px;
            text-align: center;
            padding: 1px 10px;
            border: 40px;
            border-radius: 15px;
            border: solid;
            border-color: grey;
            background-color: black;
            animation: changeColor 0.5s infinite alternate; /* Animation added */
        }

        a:hover {
            background-color: whitesmoke;
            color: blue;
            animation: none; /* Disable animation on hover */
        }

        @keyframes changeColor {
            0% {
                color: white;
            }

            50% {
                color: green;
            }

            100% {
                color: white;
            }
        }

        h1 {
            font-size: 50px;
            color: blue;
            margin-top: 200px;
            margin-left: 600px;
            animation: bounceText 0s infinite alternate; /* Animation */
        }

        @keyframes bounceText {
            0% {
                transform: translateY(0); /* Start position */
            }
            50% {
                transform: translateY(-40px); /* Upward */
            }
            100% {
                transform: translateY(0); /* Back to the start position */
            }
        }

        .linkname {
            display: block;
            height: 70px;
            width: 100%;
            background-color: transparent;
            color: white;
            margin-left: 440px;
            margin-top: 30px;
            text-align: center;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            height: 200px;
            background-color: black;
            color: white;
            font-size: 30px;
            text-align: center;
            padding-top: 10px;
        }

        /* Animation for paragraph */
        .footer p {
            animation: moveText 20s linear infinite;
        }

        @keyframes moveText {
    0% {
        transform: translateX(100%); /* Start from right */
    }
    100% {
        transform: translateX(-100%); /* Move to left */
    }
}

        
    </style>
</head>
<body>
<div class="body">
    <div class="linkname">
      
        <b><a href="recelogin.php">Reception</a></b>
        <b><a href="doctorlogin.php">Doctor</a></b>
        <b><a href="laboratorylogin.php">Laboratory</a></b>
        <b><a href="cashierlogin.php">Cashier</a></b>
        <b><a href="pharmacylogin.php">Pharmacy</a></b>
        <b><a href="managementlogin.php">Management</a></b>
    </div>
    <hr>
    <br><br><br><br>
    <b><h1>WELCOME to DMG HOSPITAL for <br>better and quality HEALTHY services</b></h1>
    <br><br><br><br><br><br>
    <div class="footer">
        <p>Welcome to DMG HOSPITAL| located at Makumbusho Dar es Salaam   |Available doctors: General doctor| physician | dentists|  Email: dmg@info.com| Contacts: 0674724742<br>
        </p>
    
    </div>
</div>
</body>
</html>
