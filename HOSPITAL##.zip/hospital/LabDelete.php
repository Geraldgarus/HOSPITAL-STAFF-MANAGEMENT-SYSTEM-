<?php
include("connection.php");

$id = $_REQUEST['id'];
$query_for_select_user_row = "DELETE FROM labtable   WHERE id= $id"; 

$result = mysqli_query($conn,$query_for_select_user_row);

header("Location:labcompleted.php"); 
exit();

?>