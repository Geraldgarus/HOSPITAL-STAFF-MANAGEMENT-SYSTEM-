<?php
include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedbacks</title>
    <style>
        body {
          margin: 0;
          font-family: "Lato", sans-serif;
        }
        
        .sidebar {
          margin: 0;
          padding: 0;
          width: 250px;
          background-color: grey;
          position: fixed;
          height: 100%;
          overflow: auto;
        }
        
        .sidebar a {
          display: block;
          color: black;
          padding: 16px;
          text-decoration: none;
          font-size: 30px;

        }
         
        .sidebar a.active {
          background-color: #04AA6D;
          color: white;
        }
        
        .sidebar a:hover:not(.active) {
          background-color: #555;
          color: white;
        }
        
        .customers{
          display:block;
          width: 1500px;
          height: 2000px;
          background-color: whitesmoke;
          margin-left: 30px;
          margin-top: 60px;
          

        }
        .customers td{
        
          background-color:white;
          color:black;
         padding: 8px 90px;
          text-align:left;
         
          
        }
        .customers th{
          
          background-color:white;
          color:black;
         padding: 8px 90px;
          text-align:left;
          font-size: 25px;
          
          
       
        }
        .customers button{
          background:black;
          color:white;
          font-size: 20px;

        }
        

        
        </style>
         
</head>
<body>
<?php
include("doctor.php");
?>


<!-------my side bar here-->
   
      <table class="customers">
  <thead>
    <tr>
      <th scope="col">Number</th>
      <th scope="col">Name</th>
      <th scope="col">Investigation</th>
      <th scope="col">Results</th>
         <th scope="col">Actions</th>
    </tr>
  </thead>

  <tbody>

<!--------------SELECT ALL USERS-------->
  <?php
     $count=1;
    
      $select_all_users = "select * from labtable  order by id asc";

         $result = mysqli_query($conn,$select_all_users);
                 $number = mysqli_num_rows($result);
                 if ($number > 0) {
                     while($row = mysqli_fetch_assoc($result)) {  ?>   
                        <tr>
            
              <td><?php echo $count++ ?></td>

               <td><?php echo $row['name'];?></td>

              <td><?php echo $row['investigation'];?></td>
              <td><?php echo $row['results'];?></td>
             
             <td>
              <a href="docFeedbacksAttend.php?id=<?php echo $row['id']?>"><button type="button" class="btn btn-warning">Attend</button></a><br><br>

             </td>

                      </tr>

             <?php } }  else {
             echo "0 results"; }?>


  </tbody>
</table>
</div>

     </div>
             </div>
        </div>
      </div>
      <!---ends-->
      


</body>
</html>