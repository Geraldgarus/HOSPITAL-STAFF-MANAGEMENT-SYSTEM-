<?php
include("connection.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming $conn is your database connection

    // Check if 'id' key exists in $_POST array
    if(isset($_POST['id'])){
        // Retrieve user ID from form data
        $user_id = $_POST['id'];

        // Retrieve new password and password confirmation from form input
        $new_password = md5( $_POST['confirm_password']);
        $confirm_password = md5( $_POST['confirm_password']);

        // Check if new password matches confirmation password
        if ($new_password !== $confirm_password) {
            echo "Passwords do not match.";
        } else {
            // Update password in the database
            $update_query = "UPDATE loginrece SET password = '$new_password' WHERE id = $user_id";
            $update_result = mysqli_query($conn, $update_query);

            if ($update_result) {
                echo "Password updated successfully.";
            } else {
                echo "Error updating password: " . mysqli_error($conn);
            }
        }
    } else {
        // 'id' key is not set in $_POST array
        echo "User ID not provided.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <style>
      .shaddow{
        display:block;
        background-color:whitesmoke;
        height: 100%;
        width:100%;
        margin-left: 0px;
        position: fixed;

      }
        .form{
            display: block;
            background-color:white;
            height:700px;
            width: 1200px;
            margin-left: 100px;
            padding-left: 50px;
            margin-top: 70px;

        }
        input{
            padding: 20px 400PX;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: left;
            border-color:whitesmoke;
        

        }
        h1{
            font-size: 30px;
            text-align: center;
            color: black;
        }
       input .placeholder{
        text-align: left;
     
       }
       button{
        padding: 20px 468px;
       
        color: white;
        background-color: blue;
        
        font-size: 20px;
       }
       h2{
        font-size: 30px;

       }
       p{
        color: black;
        font-size:30px;
        margin-left:2px;
       }
       textarea{
        background-color: transparent;
        color: black;
        font-size: 0px;
        text-align: center;
        border-color: wheat;
       
       }
       a{
        color: blue;
        font-size: 30px;
        text-decoration: none;
       }
       a:hover{
        color: white;
        background-color: green;
       }
       

    </style>
</head>
<body>
<?php
include("reception1.php");
?>
<div class="shaddow">
    <div class="form">
    
    <form method="post" action="">
    <h1>Change Password</h1>
      <br><br>
      <label><h2>*New Password</h2></label>
      <input type="password" id="new_password" name="new_password"  required>
      <br>
      
      <label><h2>*confirm_password</h2></label>
      <input type="password" id="confirm_password" name="confirm_password" required><br>
        <?php 
        // Check if 'id' key exists in $_GET array and pass it as hidden field
        if(isset($_GET['id'])) { ?>
            <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
        <?php } ?>
        <br>
        <button type="submit">ChangePassword</button>
    </form>
    </div>
    </div>
</body>
</html>
