
<?php
include("connection.php");

if(isset($_POST["insert_user_data"])){
  $name  = $_POST['name'];
  $description= $_POST['description'];
  $symptoms= $_POST['symptoms'];
  $investigation= $_POST['investigation'];
 
 





  $enroll_new_patient  = "INSERT INTO  attedtable1(name,description,symptoms,investigation ) VALUES('$name','$description','$symptoms','$investigation');";

if (mysqli_query($conn,$enroll_new_patient )) {

  echo "<script>window.location='appointments.php'</script>";
} else {
  echo "wrong  try again";
}

mysqli_close($conn);

}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Registration</title>
    <style>
      
        .form{
            display: block;
            background-color:white;
            height:800px;
            width: 1400px;
            margin-left: 30px;
            padding-left: 50px;
            margin-top: 50px;

        }
        input{
            padding: 15px 470px;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: center;
            border-color:whitesmoke;
        

        }
        h1{
            font-size: 30px;
            text-align: center;
            color: black;
        }
       input .placeholder{
        text-align: left;
        background-color: black;
       }
       button{
        padding: 20px 580px;
       
        color: white;
        background-color: blue;
        
        font-size: 20px;
       }
       h2{
        font-size: 30px;

       }
       p{
        color: purple;
       }
       textarea{
        background-color: transparent;
        color: black;
        font-size: 20px;
        text-align: center;
        border-color: wheat;
       
       }
       

    </style>
  </head>
  <body>
  <?php
include("doctor.php");
?>
<div class="shaddow">
    <div class="form">
    <form action="" method="post">
      <h1>please fill the box below</h1>
      <br><br>
      <?php
                $select_user = "select * from  reception1 where id = '" .$_GET['id']. "'";
                $result = mysqli_query($conn, $select_user);
                $number = mysqli_num_rows($result);
                 if ($number > 0) {
                     while($row = mysqli_fetch_assoc($result)) {  ?>   

      
      <label><h2>*name</h2></label>
      <input type="text" name="name"  value="<?php echo $row['name']; ?>" placeholder="name">
      <br><br>
      
     
      <label><h2>*symptoms</h2></label>
      <textarea name="symptoms" rows="5" cols="113" ></textarea>
    <br>
        
    <label><h2>*investigation</h2></label>
      <textarea name="investigation" rows="5" cols="113"  ></textarea>
      <?php  } } ?>
      <br><br><br>
      <button type="submit" name="insert_user_data">submit</button>
    </form>
    </div>
    </div>
  </body>
</html>