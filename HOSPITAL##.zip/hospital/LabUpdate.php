<?php
include("connection.php");

if(isset($_POST["update"])){

    $id =$_GET["id"];
    $name =$_POST["name"];
   
    $investigation =$_POST["investigation"];
    $results =$_POST["results"];


 $update_user = "UPDATE labtable SET  name='$name',investigation='$investigation',results='$results'
    WHERE  id='$id'";

    if (mysqli_query($conn, $update_user)) {
           header("location:LABCOMPLETED.php");
           exit();
    } else {
        echo "wrong updation try again";
    }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>labUPDATE</title>
    <style>
      
     .form{
            display: block;
            background-color:white;
            height:800px;
            width: 1300px;
            margin-left: 30px;
            padding-left: 50px;
            margin-top: 50px;

        }
        input{
            padding: 15px 470px;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: center;
            border-color:whitesmoke;
        

        }
        h1{
            font-size: 30px;
            text-align: center;
            color: black;
        }
       input .placeholder{
        text-align: left;
        background-color: black;
       }
       button{
        padding: 20px 574px;
       
        color: white;
        background-color: blue;
        
        font-size: 20px;
       }
       h2{
        font-size: 30px;

       }
       p{
        color: purple;
       }
       textarea{
        background-color: transparent;
        color: black;
        font-size: 20px;
        text-align: center;
        border-color: wheat;
       
       }
       
       


    </style>
  </head>
  <body>
  <?php
include("laboratory.php");
?>



  <div class="form">
    <form action="" method="post">
    <h1>please fill the box below</h1>
                <?php
                $select_user = "select * from  labtable where id = '" .$_GET['id']. "'";
                $result = mysqli_query($conn, $select_user);
                $number = mysqli_num_rows($result);
                 if ($number > 0) {
                     while($row = mysqli_fetch_assoc($result)) {  ?>   

      
      <br><br>
      <label><h2>*name</h2></label>
      <input type="text" name="name" value="<?php echo $row['name']; ?>" placeholder="">
     <br>
     <label><h2>*investigation</h2></label>
      <input type="text" name="investigation" value="<?php echo $row['investigation']; ?>" placeholder="">
     
      <br>
      
      <label><h2>*results</h2></label>
     
      <input type="text" name="results" value="<?php echo $row['results']; ?>" placeholder="">
     
    
      <br><br>
    

 


  
    <?php  } } ?>

  <button type="submit" name="update" class="btn btn-primary">Update</button>
  </div>

</form>


</div>
<div>
</div>
</div>
<br>
 
</div>







  </body>
</html>
