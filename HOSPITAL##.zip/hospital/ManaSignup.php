
<?php
include("connection.php");

if(isset($_POST["insert_user_data"])){
  $name  = $_POST['name'];
  $email  = $_POST['email'];
  $password  =md5($_POST['password']);


$enroll_new_patient = "INSERT INTO management(name,email,password) VALUES('$name','$email','$password');";

if (mysqli_query($conn, $enroll_new_patient)) {
  echo "<script>  alert('Account created Successfully! ')    </script>";
  echo "<script>window.location='managementdashboard.php'</script>";
} else {
  echo "wrong  try again";
}

mysqli_close($conn);

}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Registration</title>
    <style>
      .shaddow{
        display:block;
        background-color:whitesmoke;
        height: 100%;
        width:100%;
        margin-left: 0px;
        position: fixed;

      }
        .form{
            display: block;
            background-color:white;
            height:790px;
            width: 1200px;
            margin-left: 300px;
            padding-left: 50px;
            margin-top: 70px;

        }
        input{
            padding: 20px 430px;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: left;
            border-color:whitesmoke;
        

        }
        h1{
            font-size: 30px;
            text-align: center;
            color: black;
        }
       input .placeholder{
        text-align: left;
        background-color: ;
       }
       button{
        padding: 20px 514px;
       
        color: white;
        background-color: blue;
        
        font-size: 20px;
       }
       h2{
        font-size: 30px;

       }
       p{
        background-color: color: black;
        font-size:30px;
        margin-left:2px;
       }
       textarea{
        background-color: transparent;
        color: black;
        font-size: 0px;
        text-align: center;
        border-color: wheat;
       
       }
       a{
        color: blue;
        font-size: 30px;
        text-decoration: none;
       }
       a:hover{
        color: white;
        background-color: green;
       }
       

    </style>
  </head>
  <body>

<div class="shaddow">
    <div class="form">
    <form action="" method="post">
      <h1>Sign up your account</h1>
      <br><br>
      <label><h2>*Name</h2></label>
      <input type="text" name="name" placeholder="name" required>
      <br>
      
      <label><h2>*Email</h2></label>
      <input type="text" name="email" placeholder="email"required>
      <br>
      
      <label><h2>*Password</h2></label>
      <input type="password" name="password" placeholder="password" required><br><br><br>
      <button type="submit" name="insert_user_data">Sign me up</button><br><br>
      <p>Already have an account? <span><a href="managementlogin.php">Sign in</a></span></p>
    </form>
    </div>
    </div>
  </body>
</html>



