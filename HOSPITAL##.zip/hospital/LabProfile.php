<?php
include("connection.php");

if(isset($_POST["update"])){
    $id = $_GET["id"];
    $name = $_POST["name"];
    $email = $_POST["email"];
    // Don't update password here, it's not being changed in this form
    $update_user = "UPDATE loginlaboratory SET name='$name', email='$email' WHERE id='$id'";
    if (mysqli_query($conn, $update_user)) {
        header("location:sellerdashboard.php");
        exit();
    } else {
        echo "Wrong updation. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Profile</title>
    <style>
        .form {
            display: block;
            background-color: transparent;
            max-width: 400px; /* Adjusted width */
            margin: 50px auto; /* Center the form */
            padding: 20px;
            border: 2px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        input {
            padding: 10px; /* Adjusted padding */
            color: black;
            background-color: transparent;
            margin-bottom: 20px; /* Added margin-bottom */
            width: 100%; /* Make inputs full-width */
            box-sizing: border-box; /* Include padding in width */
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        
        h1 {
            font-size: 24px;
            text-align: center;
            color: #333;
            margin-bottom: 20px; /* Added margin-bottom */
        }
        
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        
        button:hover {
            background-color: #0056b3;
        }

        .avatar {
            display: block;
            margin: 0 auto;
            width: 150px; /* Adjust as needed */
            height: 150px; /* Adjust as needed */
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 20px; /* Added margin-bottom */
        }
    </style>
</head>
<body>
    <?php include("laboratory.php"); ?>

    <div class="form">
        <form action="" method="post">
            <h1>PROFILE</h1>
            <?php
            $select_user = "SELECT * FROM loginlaboratory WHERE id = '" .$_GET['id']. "'";
            $result = mysqli_query($conn, $select_user);
            $number = mysqli_num_rows($result);
            if ($number > 0) {
                while($row = mysqli_fetch_assoc($result)) {  ?>   
                   <img class="avatar"  src="profileicon.png" style="width: 100px;height:100px;" ><br>
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>" placeholder="Name" required>
                    
                    <label for="email">Email:</label>
                    <input type="text" id="email" name="email" value="<?php echo $row['email']; ?>" placeholder="Email" required>
            <?php }} ?>
           
        </form>
    </div>
</body>
</html>
