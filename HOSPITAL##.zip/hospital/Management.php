<!DOCTYPE html>
<!-- Website - www.codingnepalweb.com -->
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <title>management</title>
  <link rel="stylesheet" href="hogo9.css" />
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
   


    /* Dropdown Button */
    .dropbtn {
      background-color: black;
      color: white;
      padding: 16px;
      font-size: 16px;
      border: none;
      cursor: pointer;
      min-width: 200px; /* Set a fixed width */
      box-sizing: border-box; /* Include padding in width */
    }

    /* Dropdown button on hover & focus */
    .dropbtn:hover, .dropbtn:focus {
      background-color: #2980b9;
    }

    /* The container <div> - needed to position the dropdown content */
    .dropdown {
      position: relative;
      display: inline-block;
    }

    /* Dropdown Content (Hidden by Default) */
    .dropdown-content {
      display: none;
      position: absolute;
      background-color:white;
      min-width: 200px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1;
    }

    /* Links inside the dropdown */
    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    /* Change color of dropdown links on hover */
    .dropdown-content a:hover {
      background-color: #f1f1f1;
      animation: bounceLink 0.5s infinite alternate; /* Bounce animation */
    }

    @keyframes bounceLink {
      0% {
        transform: translateY(0);
      }
      100% {
        transform: translateY(-5px);
      }
    }

    /* Show the dropdown menu on hover */
    .dropdown:hover .dropdown-content {display: block;}

    /* Change the background color of the dropdown button when the dropdown content is shown */
    .dropdown:hover .dropbtn {background-color: #2980b9;}

    /* Profile image */
    .profile-details img {
      width: 40px; /* Adjust the size of the profile image */
      border-radius: 50%; /* Make the image round */
      margin-right: 10px; /* Add some spacing */
    }

    /* Sidebar links */
    .nav-links li a:hover {
      animation: bounceLink 0.3s infinite alternate;
    }

  </style>
</head>

<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class="bx bxl-c-plus-plus"></i>
      <span class="logo_name">MANAGEMENT</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="managementdashboard.php" class="active">
          <i class="bx bx-grid-alt"></i>
          <span class="links_name">Dashboard</span>
        </a>
      </li>
      <li>
        <a href="managerappointments.php">
        <i class="bx bx-calendar"></i>
          <span class="links_name">Appointments</span>
        </a>
      </li>
      <li>
        <a href="manapatients.php">
        <i class="bx bx-user"></i>
          <span class="links_name">Patients</span>
        </a>
      </li>
      <li>
        <a href="managerfeedbacks.php">
        <i class="bx bx-message-square-detail"></i>
          <span class="links_name">Feedbacks</span>
        </a>
      </li>
      <li>
        <a href="managercompleted.php">
        <i class="bx bx-check"></i>
          <span class="links_name">Completed</span>
        </a>
      </li>
      <li>
        <a href="managercash.php">
        <i class="bx bx-money"></i>
          <span class="links_name">Cash</span>
        </a>
      </li>
     
    
      <li>
    </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class="bx bx-menu sidebarBtn"></i>
        <span class="dashboard">Dashboard</span>
      </div>
     
     
        <div class="dropdown">
        <button class="dropbtn"><img src="usericon.png" style="width: 40px; height: 40px;"></button>
            <div class="dropdown-content">
            <?php
            $select_user = "SELECT * FROM management LIMIT 1";
            $result = mysqli_query($conn, $select_user);
            $number = mysqli_num_rows($result);
            if ($number > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    // Dynamic link for profile
                    $profile_link = "managerprofile.php?id=" . urlencode($row['id']);
                    // Dynamic link for password change
                    $password_change_link = "managerchangepassword.php?id=" . urlencode($row['id']);
            ?>
                <!-- Profile link -->
                <a href="<?php echo $profile_link; ?>"><i class='bx bx-user'></i>Profile</a>
                <!-- Password change link -->
                <a href="<?php echo $password_change_link; ?>"><i class='bx bx-lock'></i>Password</a>
            <?php
                }
            }
            ?>
            <!-- Logout link -->
            <a href="logout.php"><i class='bx bx-log-out'></i>Logout</a>
            </div>
        </div>
    </div>
</div>

  
      </div>
    </nav>
<br><br><br>
    
</body>

</html>
