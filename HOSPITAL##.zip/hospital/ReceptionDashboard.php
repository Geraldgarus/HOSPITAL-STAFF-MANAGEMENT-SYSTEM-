<?php
session_start();
include("connection.php");
?>

<!DOCTYPE html>
<!-- Website - www.codingnepalweb.com -->
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <title>DASHBOARD</title>
  <link rel="stylesheet" href="hogo9.css" />
  <style>
    .box {
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
      margin: 20px 0;
      animation: bounce 2s infinite; /* Apply bouncing animation */
    }

    .box:hover {
      animation: none; /* Stop animation on hover */
    }

    @keyframes bounce {
      0%, 20%, 50%, 80%, 100% {
        transform: translateY(0);
      }
      40% {
        transform: translateY(-30px);
      }
      60% {
        transform: translateY(-15px);
      }
    }
  </style>
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body>
<?php
include("reception1.php");

?>
<div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Registered</div>
            <div class="number">
            <?php
$countusers = mysqli_query($conn, "select id from reception1");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
            </div>
            <div class="indicator">
            <i class="bx bx-user-plus"></i>
             
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Completed</div>
            <div class="number">
            <?php
$countusers = mysqli_query($conn, "select id from phamaconfirm");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
            </div>
            <div class="indicator">
            <i class="bx bx-check"></i>
             
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Feedbacks</div>
            <div class="number">
            <?php
$countusers = mysqli_query($conn, "select id from labtable");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
            </div>
            <div class="indicator">
            <i class="bx bx-message-square-detail"></i>
            
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Discharched</div>
            <div class="number">
            <?php
$countusers = mysqli_query($conn, "select id from phamaconfirm");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
            </div>
            <div class="indicator">
            <i class="bx bx-check-circle"></i>
             
            </div>
          </div>
        </div>
      </div>
      <div class="center">
      </div>
    </div>
</body>

</html>

<div class="home-content">
  <div class="overview-boxes">
    <!-- Your PHP code for boxes goes here -->
  </div>
  <div class="center">
  </div>
</div>

<script>
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".sidebarBtn");
  sidebarBtn.onclick = function() {
    sidebar.classList.toggle("active");
    if (sidebar.classList.contains("active")) {
      sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
    } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
  };
</script>
</body>

</html>
