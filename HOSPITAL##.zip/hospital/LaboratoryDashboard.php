<?php
include("connection.php");

?>

<!DOCTYPE html>
<!-- Website - www.codingnepalweb.com -->
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <title>DASHBOARD</title>
  <link rel="stylesheet" href="hogo9.css" />
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body>
<?php
include("laboratory.php");

?>
<div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Appointments</div>
            <div class="number">
            <?php
$countusers = mysqli_query($conn, "select id from attedtable1");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
            </div>
            <div class="indicator">
            <i class="bx bx-calendar"></i>
              <span class="text"> Today</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Completed</div>
            <div class="number">
            <?php
$countusers = mysqli_query($conn, "select id from labtable  ");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
            </div>
            <div class="indicator">
            <i class="bx bx-check"></i>
              <span class="text"> Today</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Patients</div>
            <div class="number">
            <?php
$countusers = mysqli_query($conn, "select id from reception1  ");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
            </div>
            <div class="indicator">
            <i class="bx bx-user"></i>
              <span class="text"> Today</span>
            </div>
          </div>
          <i class="bx bx-down-arrow-alt down"></i>
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">discharched</div>
            <div class="number">
            <?php
$countusers = mysqli_query($conn, "select id from phamaconfirm  ");
$user = mysqli_num_rows($countusers);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?>
            </div>
            <div class="indicator">
              <i class="bx bx-down-arrow-alt down"></i>
              <span class="text"> Today</span>
            </div>
          </div>
        </div>
      </div>
      <div class="center">
      </div>
    </div>
</body>

</html>





</div>
</div>
</section>

<script>
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".sidebarBtn");
  sidebarBtn.onclick = function() {
    sidebar.classList.toggle("active");
    if (sidebar.classList.contains("active")) {
      sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
    } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
  };
</script>
</body>

</html>