<?php
include("connection.php");
session_start();


if (isset($_POST['login1'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);

	
$select_user_data_for_login = mysqli_query($conn, "SELECT * FROM `management` WHERE `email` = '$email' AND `password` = '$password'");
	
 
	$row = mysqli_num_rows($select_user_data_for_login);

	if ($row > 0) {
         
           
		echo "<script>  alert('You are  Successfully! login')    </script>";
		echo "<script>window.location='managementdashboard.php'</script>";
           

	} else {
		echo "<script>alert('Wrong! invald email or passsword')</script>";
		echo "<script>window.location='managementlogin.php'</script>";
	}

}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>login</title>
    <style>
      .shaddow{
        display:block;
        background-color:whitesmoke;
        height: 100%;
        width:100%;
        margin-left: 0px;
        position: fixed;

      }
        .form{
            display: block;
            background-color:white;
            height:600px;
            width: 1300px;
            margin-left: 300px;
            padding-left: 50px;
            margin-top: 70px;

        }
        input{
            padding: 15px 470px;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: left;
            border-color:whitesmoke;
        

        }
        h1{
            font-size: 30px;
            text-align: center;
            color: black;
        }
       input .placeholder{
        text-align: left;
      
       }
       button{
        padding: 20px 570px;
       
        color: white;
        background-color: blue;
        
        font-size: 20px;
       }
       h2{
        font-size: 30px;

       }
       p{
        color: black;
        font-size:30px;
        margin-left:2px;
       }
       textarea{
        background-color: transparent;
        color: black;
        font-size: 20px;
        text-align: center;
        border-color: wheat;
       
       }
       a{
        color: blue;
        font-size: 30px;
        text-decoration: none;
       }
       a:hover{
        color: white;
        background-color: green;
       }
       
       

    </style>
  </head>
  <body>

<div class="shaddow">
    <div class="form">
    <form action="" method="post">
      <h1>sign in your account</h1>
      <br><br>
      <label><h2>*Email</h2></label>
      <input type="text" name="email" placeholder="email" required>
      <br>
      
      <label><h2>*Password</h2></label>
      <input type="password" name="password" placeholder="password" required><br><br><br>
      <button type="submit" name="login1">Sign in</button><br>
      <p>Don't have an account? <span><a href="manasignup.php">Sign up</a></span></p>
    </form>
    </div>
    </div>
  </body>
</html>







